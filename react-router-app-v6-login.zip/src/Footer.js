import { Container } from 'react-bootstrap';

function Footer() {

    return (
        <Container className="bg-secondary" fluid>
            <Container>
                <p className="py-1">Copyright © All right reserved.</p>
            </Container>
        </Container>
        
    );
}


export default Footer;