import '../../App.css';

function Aestree() {
  return (
    <div>
        <h5>Aestree</h5>
        <p>Aestree ERP, is a complete School Management System consists of Aestree Software, Web Portal and Mobile App. The complete Aestree package is developed and maintained by Aayesha Enterprise.</p>
    </div>
  );
}

export default Aestree;
